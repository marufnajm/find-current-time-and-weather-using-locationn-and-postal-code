const request = require('request');
let apiKey = 'c0c0fa32e9e959d9a14465b140d5c194';
let location = 'chicago';
let zip = '94110';
let url = `http://api.openweathermap.org/data/2.5/weather?q=${location}&units=imperial&appid=${apiKey}`
let moment = require('moment-timezone'); 
let zipcode_to_timezone = require( 'zipcode-to-timezone' );


request(url, function (err, response, body) {
	if(err){
	    console.log('error:', error);
	}else {
	  	// console.log(body);
	    let weather = JSON.parse(body)
	    let message = `It's ${weather.main.temp} degrees in ${weather.name}!`;
	    console.log(message); // print the weather
		let tz = zipcode_to_timezone.lookup(zip);
		let time = moment().tz(tz).format("HH:mm A");
		console.log(`It is ${time}`);  // print the time
  }
});